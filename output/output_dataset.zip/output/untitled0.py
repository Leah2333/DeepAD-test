# -*- coding: utf-8 -*-
"""
Created on Thu Dec  8 17:50:44 2022

@author: Surface
"""

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import math

path=[]
path.append("D:/temp/k/RL_AV/micro_RL/output/0")
path.append("D:/temp/k/RL_AV/micro_RL/output/1")
path.append("D:/temp/k/RL_AV/micro_RL/output/20")
path.append("D:/temp/k/RL_AV/micro_RL/output/40")
path.append("D:/temp/k/RL_AV/micro_RL/output/60")
path.append("D:/temp/k/RL_AV/micro_RL/output/80")
path.append("D:/temp/k/RL_AV/micro_RL/output/100")
real=[]
size = 50
total_length = 1750
x=[]
m=0
for i in range(size):
    x.append(int(m))
    m+=total_length/size
for ii in path:
    
    dist=np.array(pd.read_csv(ii+"/dist_list.csv"))
    speed=np.array(pd.read_csv(ii+"/speed_list.csv"))
    

    """
    pj=[]
    for i in range(size):
        pj.append([])
    for i in range(len(dist)):
        for j in range(len(dist[i])):
            if dist[i][j]!=-1 and math.isnan(dist[i][j])==0 and math.isnan(speed[i][j])==0 :
                #print(dist[i][j])
                pj[int(dist[i][j])//int(total_length/size)].append(speed[i][j])
    print(pj)
    av=[]
    for i in pj:
        if len(i)!=0:
            av.append(np.mean(i))
        else:
            av.append(0)
            
    print(av)
    """
    #平均离开时间
    pj2=[]
    for i in range(size):
        pj2.append([])
    for j in range(len(dist[0])):
        pre=0
        before=0
        for i in range(len(dist)):
            if dist[i][j]==-1:
                before=i
                continue
            if math.isnan(dist[i][j])==0:
                #print(dist[i][j])
                if float(dist[i][j])>(pre+1)*(total_length/size):
                    pj2[pre].append(i-before)
                    before=i
                    pre+=1
    
    bv=[]
    for i in pj2:
        if len(i)!=0:
            bv.append(np.mean(i))
        else:
            bv.append(0)
            
    print(len(bv))
    real.append(bv)
y=[0,1,20,40,60,80,100]
#sns.set_theme()
#f, ax = plt.subplots(figsize=(9, 6))
df = pd.DataFrame(real, index=y, columns=x)

#df = df.pivot("distance", "The occupation of AV", "time")
#sns.heatmap(df,center=0.1)


sns.set()
plt.rcParams['font.sans-serif']='Arial'#设置中文显示，必须放在sns.set之后
np.random.seed(0)
f, ax = plt.subplots(figsize=(9, 3))

#heatmap后第一个参数是显示值,vmin和vmax可设置右侧刻度条的范围,
#参数annot=True表示在对应模块中注释值
# 参数linewidths是控制网格间间隔
#参数cbar是否显示右侧颜色条，默认显示，设置为None时不显示
#参数cmap可调控热图颜色，具体颜色种类参考：https://blog.csdn.net/ztf312/article/details/102474190
sns.heatmap(df, ax=ax,annot=False,linewidths=0,cbar=True)

ax.set_title('Space-Occupation Heatmaps of Mean Travel Time using RL-based Controller for severe Congestion') #plt.title('热图'),均可设置图片标题
ax.set_xlabel('distance')  #设置纵轴标签
ax.set_ylabel('The occupation of AV')  #设置横轴标签

#设置坐标字体方向，通过rotation参数可以调节旋转角度
label_y = ax.get_yticklabels()
plt.setp(label_y, rotation=360, horizontalalignment='right')
label_x = ax.get_xticklabels()
plt.setp(label_x, rotation=45, horizontalalignment='right')

plt.show()



